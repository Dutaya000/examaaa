from num2words import num2words

# Solicitar el número al usuario
numero = int(input("Ingrese un número entre 0 y 5000: "))

# Verificar que el número esté en el rango permitido
if 0 <= numero <= 5000:
    # Convertir el número a palabras en español
    numero_en_letras = num2words(numero, lang='es')
    print(f"El número {numero} en letras es: {numero_en_letras}")
else:
    print("El número ingresado no está en el rango permitido.")
