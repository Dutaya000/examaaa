def control_pesca():
    # Pedir el límite máximo permitido por la ley
    try:
        limite_maximo = float(input("Introduce el límite máximo permitido en Kg de pesca: "))
        if limite_maximo <= 0:
            print("El límite máximo debe ser mayor que cero. Fin del programa.")
            return
    except ValueError:
        print("Por favor, introduce un número válido. Fin del programa.")
        return

    # Inicializar variables
    total_pescado = 0  # Total de Kg. pescados
    sobrepaso = 0  # Kg en los que se ha sobrepasado el límite
    terminar = False

    print("Introduce los Kg. pescados en cada captura. Escribe 0 para terminar.")
    
    while not terminar:
        try:
            peso = float(input("Introduce el peso de la captura en Kg: "))
            
            if peso < 0:
                print("Error: No puedes introducir un peso negativo. Inténtalo de nuevo.")
                continue  # Salta a la siguiente iteración
            
            if peso == 0:
                # Finalizar el programa si el usuario introduce un 0
                print("Finalizando registro de pesca.")
                break
            
            # Sumar el peso al total
            total_pescado += peso
            print(f"Total acumulado: {total_pescado} Kg.")
            
            # Verificar si se ha sobrepasado el límite
            if total_pescado > limite_maximo:
                sobrepaso = total_pescado - limite_maximo
                print(f"¡Alarma! Límite superado. Total pescado: {total_pescado} Kg. Te has pasado por {sobrepaso} Kg.")
                terminar = True  # Finalizar el programa cuando se supere el límite
        except ValueError:
            print("Por favor, introduce un número válido para el peso.")
    
    # Resumen final
    if total_pescado <= limite_maximo:
        print(f"Pesca registrada correctamente. Total pescado: {total_pescado} Kg. No se ha sobrepasado el límite.")
    else:
        print(f"Pesca registrada con exceso. Total pescado: {total_pescado} Kg. Sobrepaso: {sobrepaso} Kg.")

# Ejecutar el programa
control_pesca()
