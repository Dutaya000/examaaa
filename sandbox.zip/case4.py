#pedimos un numero al usuario
n=int(input("Cuantos numeros perfectos deseas encontrar "))
if n>0:

else: 
    prin("El numero ingresado es  invalido, vuelva a ingresar")

def esNumeroPerfecto(num):

def generarNumeroPerfectos(n):
    numerosPerfector=[]
    numero=2

    while len(numerosPerfectos)<n:
        if esNumeroPerfecto(numero):
            numerosPerfector.append(numero)
        numero = numero+1
    return numerosPerfectos

def main():
    
