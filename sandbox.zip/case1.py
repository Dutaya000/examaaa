diasSemana=["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"]

dia1=input("Dime que dia fue el 1 de este mes: ")
diaActual=input("Dime que dia es hoy: ")
#Encontramos losindices de los dias 
indiceDia1=diasSemana.index(dia1)
indiceDiaActual= diasSemana.index(diaActual)

#Calculamos la difencia de los dias 
diferencia= (indiceDiaActual-indiceDia1)%7
#calculamos el dia 

dia=(indiceDia1 + diferencia)%7

#print(f"Hoy es {diasSemana[(indiceDia1 + diferencia) % 7]}.")
print("Hoy es:",diasSemana[dia])
